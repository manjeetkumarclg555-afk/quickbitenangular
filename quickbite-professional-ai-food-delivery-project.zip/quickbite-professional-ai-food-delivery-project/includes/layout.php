<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/intelligence.php';

function render_header(string $title): void
{
    $user = current_user();
    $flash = get_flash();
    $cartItems = 0;
    $unreadNotifications = 0;

    if ($user) {
        global $conn;
        $cartItems = cart_count($conn, (int) $user['id']);
        $unreadNotifications = unread_notification_count($conn, (int) $user['id']);
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo h($title . ' | ' . app_name()); ?></title>
    <link rel="stylesheet" href="<?php echo h(app_path('css/style.css')); ?>">
</head>
<body>
    <header class="site-header">
        <div class="header-brand">
            <a class="brand-logo" href="<?php echo h(app_path('index.php')); ?>">
                <img class="imglogo" src="<?php echo h(app_path('images/online_delivery_logo.jpeg')); ?>" alt="Logo">
            </a>
            <a class="brand-text" href="<?php echo h(app_path('index.php')); ?>"><?php echo h(app_name()); ?></a>
        </div>
        <nav class="main-nav">
            <a href="<?php echo h(app_path('index.php')); ?>">Home</a>
            <a href="<?php echo h(app_path('menu.php')); ?>">Menu</a>
            <a href="<?php echo h(app_path('about.php')); ?>">About</a>
            <a href="<?php echo h(app_path('contact.php')); ?>">Contact</a>
            <?php if ($user): ?>
                <a class="nav-user nav-profile-link" href="<?php echo h(app_path('profile.php')); ?>">
                    <span class="nav-user-icon" aria-hidden="true"><?php echo strtoupper(substr((string) $user['name'], 0, 1)); ?></span>
                    <span class="nav-user-name"><?php echo h($user['name']); ?></span>
                </a>
                <a href="<?php echo h(app_path('history.php')); ?>">
                    History
                    <?php if ($unreadNotifications > 0): ?>
                        <span class="badge"><?php echo $unreadNotifications; ?></span>
                    <?php endif; ?>
                </a>
                <a href="<?php echo h(app_path('cart.php')); ?>">Cart <span class="badge"><?php echo $cartItems; ?></span></a>



                <?php if (($user['role'] ?? '') === 'admin'): ?>
                    <a href="<?php echo h(app_path('admin/dashboard.php')); ?>">Admin</a>
                    <a href="<?php echo h(app_path('admin/ai-modeling.php')); ?>">AI Lab</a>
                <?php endif; ?>
                <a href="<?php echo h(app_path('logout.php')); ?>">Logout</a>
            <?php else: ?>
                <a href="<?php echo h(app_path('login.php')); ?>">Login</a>
                <a href="<?php echo h(app_path('profile.php')); ?>">Profile</a>
                <a href="<?php echo h(app_path('register.php')); ?>" class="nav-cta">Sign Up</a>
            <?php endif; ?>


        </nav>
    </header>
    <?php if ($flash): ?>
        <div class="flash flash-<?php echo h($flash['type']); ?>">
            <?php echo h($flash['message']); ?>
        </div>
    <?php endif; ?>
    <main class="page-shell">
    <?php
}

function render_footer(): void
{
    $year = date('Y');
    $user = current_user();
    $isAdmin = $user && (($user['role'] ?? '') === 'admin');
    $assistantGreeting = $user
        ? 'Hi ' . $user['name'] . ', ask for dish recommendations, order status, payments, or support help.'
        : 'Ask for menu recommendations, payment help, delivery hours, or support contact.';
    ?>
    </main>
    <footer class="site-footer">
        <div class="footer-grid">
            <section class="footer-brand-block">
                <h2><?php echo h(app_name()); ?></h2>
                <p>QuickBite evolved from a local food delivery idea into a tech-enabled platform that connects restaurants, customers, and delivery partners, focusing on speed, convenience, and scalability.</p>
                <div class="footer-contact-list">
                    <span>Email: manjeetkumarclg555@gmail.com</span>
                    <span>Phone: +91 7070294101</span>
                </div>
            </section>
            <section>
                <h3>Operations</h3>
                <div class="footer-links">
                    <a href="<?php echo h(app_path('menu.php')); ?>">Browse Menu</a>
                    <a href="<?php echo h(app_path('history.php')); ?>">Order History</a>
                    <?php if ($isAdmin): ?>
                        <a href="<?php echo h(app_path('admin/dashboard.php')); ?>">Dispatch Dashboard</a>
                        <a href="<?php echo h(app_path('admin/ai-modeling.php')); ?>">AI Modeling Center</a>
                    <?php else: ?>
                        <a href="<?php echo h(app_path('order.php')); ?>">Checkout</a>
                        <!-- <a href="<?php echo h(app_path('register.php')); ?>">Create Account</a> -->
                    <?php endif; ?>
                    <a href="https://wa.me/917070294101?text=I%20want%20to%20order" class="btn btn-success" target="_blank">Order on WhatsApp</a>
                    <a href="https://instagram.com/bihari_babu_9505" class="btn btn-danger" target="_blank">Visit Instagram</a>
                    <a href="https://github.com/manjeetkumarclg555-afk"  class="btn btn-dark" target="_blank"><i class="bi bi-github"></i> GitHub</a> 
                    <a href="https://facebook.com/Roy Ji"  class="btn btn-primary"  target="_blank"> Visit Facebook</a>
                </div>
            </section>
            <section>
                <h3>Platform</h3>
                <div class="footer-links">
                    <a href="<?php echo h(app_path('about.php')); ?>">About Us</a>
                    <a href="<?php echo h(app_path('contact.php')); ?>">Contact</a>
                    <a href="<?php echo h(app_path('login.php')); ?>">Customer Login</a>
                    <?php if ($isAdmin): ?>
                        <a href="<?php echo h(app_path('admin/export-preprocessed-data.php')); ?>">Download AI Dataset</a>
                    <?php else: ?>
                        <a href="<?php echo h(app_path('register.php')); ?>">Create Account</a>
                    <?php endif; ?>
                </div>
            </section>
            <section>
                <h3>Service Hours</h3>
                <div class="footer-links footer-text-only">
                    <span>Monday - Friday: 10:00 AM to 11:00 PM</span>
                    <span>Saturday - Sunday: Only for Party Booking </span>
                    <span>The platform expanded with features like real-time tracking, and multi-sided apps for customers, restaurants, and drivers—processing thousands of orders daily</span>
                </div>
            </section>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo h($year); ?> <?php echo h(app_name()); ?>. Professional online food delivery operations by Manjeet Kumar Roy & Chandan Kumar.</p>
        </div>
    </footer>
    <div class="chatbot-shell" id="quickbite-chatbot">
        <button class="chatbot-launcher" id="chatbot-launcher" type="button" aria-expanded="false" aria-controls="chatbot-panel">
            <span class="chatbot-launcher-icon" aria-hidden="true">AI</span>
            <span class="chatbot-launcher-text">Help</span>
        </button>
        <section class="chatbot-panel" id="chatbot-panel" hidden>
            <div class="chatbot-header">
                <div>
                    <p class="eyebrow">QuickBite AI</p>
                    <h2>Recommendation Helpdesk</h2>
                </div>
                <button class="chatbot-close" id="chatbot-close" type="button" aria-label="Close assistant">&#10005;</button>
            </div>
            <div class="chatbot-log" id="chatbot-log">
                <article class="chatbot-bubble chatbot-bubble-bot">
                    <p><?php echo h($assistantGreeting); ?></p>
                </article>
            </div>
            <div class="chatbot-chip-row" id="chatbot-chip-row">
                <button class="chatbot-chip" type="button" data-prompt="Recommend something for me">Recommend something</button>
                <button class="chatbot-chip" type="button" data-prompt="Track my latest order">Track my order</button>
                <button class="chatbot-chip" type="button" data-prompt="Show cheap dishes">Show cheap dishes</button>
                <button class="chatbot-chip" type="button" data-prompt="Payment options">Payment options</button>
            </div>
            <form class="chatbot-form" id="chatbot-form">
                <input class="chatbot-input" id="chatbot-input" type="text" placeholder="Ask about dishes, orders, or help..." autocomplete="off">
                <button class="button primary" type="submit">Send</button>
            </form>
        </section>
    </div>
    <script>
    (() => {
        const shell = document.getElementById('quickbite-chatbot');
        const launcher = document.getElementById('chatbot-launcher');
        const panel = document.getElementById('chatbot-panel');
        const closeButton = document.getElementById('chatbot-close');
        const log = document.getElementById('chatbot-log');
        const form = document.getElementById('chatbot-form');
        const input = document.getElementById('chatbot-input');
        const chipRow = document.getElementById('chatbot-chip-row');

        if (!shell || !launcher || !panel || !closeButton || !log || !form || !input || !chipRow) {
            return;
        }

        const endpoint = <?php echo json_encode(app_path('ai-chat.php')); ?>;

        const setOpen = (open) => {
            panel.hidden = !open;
            panel.style.display = open ? 'grid' : 'none';
            launcher.setAttribute('aria-expanded', open ? 'true' : 'false');
            shell.classList.toggle('is-open', open);
            if (open) {
                input.focus();
            }
        };

        const renderBubble = (text, type = 'bot') => {
            const article = document.createElement('article');
            article.className = `chatbot-bubble chatbot-bubble-${type}`;
            const paragraph = document.createElement('p');
            paragraph.textContent = text;
            article.appendChild(paragraph);
            log.appendChild(article);
            log.scrollTop = log.scrollHeight;
        };

        const renderDishCards = (dishes) => {
            if (!Array.isArray(dishes) || dishes.length === 0) {
                return;
            }

            const grid = document.createElement('div');
            grid.className = 'chatbot-dish-grid';

            dishes.forEach((dish) => {
                const card = document.createElement('article');
                card.className = 'chatbot-dish-card';

                const image = document.createElement('img');
                image.src = dish.image;
                image.alt = dish.name;
                image.loading = 'lazy';

                const title = document.createElement('strong');
                title.textContent = dish.name;

                const meta = document.createElement('span');
                meta.className = 'chatbot-dish-meta';
                meta.textContent = `${dish.category} • ${dish.price}`;

                const description = document.createElement('p');
                description.textContent = dish.description;

                card.append(image, title, meta, description);
                grid.appendChild(card);
            });

            log.appendChild(grid);
            log.scrollTop = log.scrollHeight;
        };

        const renderChips = (chips) => {
            chipRow.replaceChildren();
            (Array.isArray(chips) ? chips : []).slice(0, 4).forEach((chip) => {
                const button = document.createElement('button');
                button.type = 'button';
                button.className = 'chatbot-chip';
                button.dataset.prompt = chip;
                button.textContent = chip;
                chipRow.appendChild(button);
            });
        };

        const setLoading = (loading) => {
            form.classList.toggle('is-loading', loading);
            input.disabled = loading;
            form.querySelector('button[type="submit"]').disabled = loading;
        };

        const sendMessage = async (message) => {
            const trimmed = message.trim();
            if (trimmed === '') {
                return;
            }

            setOpen(true);
            renderBubble(trimmed, 'user');
            setLoading(true);

            try {
                const response = await fetch(endpoint, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({message: trimmed}),
                });

                const payload = await response.json();
                if (!response.ok) {
                    throw new Error(payload.error || 'Assistant request failed.');
                }

                renderBubble(payload.reply || 'I could not prepare a response right now.');
                renderDishCards(payload.dishes || []);
                renderChips(payload.chips || []);
            } catch (error) {
                renderBubble(error.message || 'Assistant is unavailable right now.');
            } finally {
                setLoading(false);
                input.value = '';
            }
        };

        launcher.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            setOpen(panel.hidden);
        });

        closeButton.addEventListener('mousedown', (event) => {
            event.preventDefault();
            event.stopPropagation();
            setOpen(false);
        });

        closeButton.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            setOpen(false);
        });

        form.addEventListener('submit', (event) => {
            event.preventDefault();
            void sendMessage(input.value);
        });

        chipRow.addEventListener('click', (event) => {
            const target = event.target;
            if (!(target instanceof HTMLButtonElement)) {
                return;
            }
            const prompt = target.dataset.prompt || target.textContent || '';
            void sendMessage(prompt);
        });

        document.addEventListener('click', (event) => {
            if (panel.hidden) {
                return;
            }

            if (!shell.contains(event.target)) {
                setOpen(false);
            }
        });

        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && !panel.hidden) {
                setOpen(false);
            }
        });

        setOpen(false);
    })();
    </script>
</body>
</html>
    <?php
}
?>
