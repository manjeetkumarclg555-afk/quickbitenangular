<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/intelligence.php';
require_once __DIR__ . '/recommendation_engine.php';

function ai_assistant_normalize(string $message): string
{
    $message = strtolower(trim($message));
    $message = preg_replace('/[^a-z0-9\s]/', ' ', $message) ?? '';
    $message = preg_replace('/\s+/', ' ', $message) ?? '';

    return trim($message);
}

function ai_assistant_message_has(string $message, array $patterns): bool
{
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $message) === 1) {
            return true;
        }
    }

    return false;
}

function ai_assistant_fetch_menu_catalog(mysqli $conn): array
{
    $result = $conn->query(
        'SELECT f.id, f.name, f.category, f.description, f.image, f.price,
                COALESCE(SUM(oi.quantity), 0) AS popularity
         FROM food_items f
         LEFT JOIN order_items oi ON oi.food_id = f.id
         GROUP BY f.id, f.name, f.category, f.description, f.image, f.price
         ORDER BY f.name'
    );

    $items = [];
    while ($row = $result->fetch_assoc()) {
        $items[] = [
            'id' => (int) $row['id'],
            'name' => (string) $row['name'],
            'category' => (string) $row['category'],
            'description' => (string) $row['description'],
            'image' => resolve_food_image((string) $row['image'], (string) $row['name'], (string) $row['category']),
            'price' => (float) $row['price'],
            'popularity' => (int) $row['popularity'],
        ];
    }

    return $items;
}

function ai_assistant_recommendation_cards(mysqli $conn, ?int $userId, int $limit = 3): array
{
    $rows = $userId !== null
        ? fetch_dish_recommendations($conn, $userId, $limit)
        : fetch_recommended_dishes($conn, null, $limit);

    return array_map(
        static function (array $dish): array {
            return [
                'name' => (string) $dish['name'],
                'category' => (string) $dish['category'],
                'description' => (string) $dish['description'],
                'price' => format_price((float) $dish['price']),
                'image' => resolve_food_image((string) $dish['image'], (string) $dish['name'], (string) $dish['category']),
            ];
        },
        array_slice($rows, 0, $limit)
    );
}

function ai_assistant_rank_menu(array $catalog, string $message, int $limit = 4): array
{
    $normalized = ai_assistant_normalize($message);
    if ($normalized === '') {
        return [];
    }

    $tokens = array_values(array_filter(explode(' ', $normalized)));
    $ranked = [];

    foreach ($catalog as $item) {
        $name = strtolower($item['name']);
        $category = strtolower($item['category']);
        $description = strtolower($item['description']);
        $score = 0;

        foreach ($tokens as $token) {
            if ($token === '') {
                continue;
            }

            if ($name === $token) {
                $score += 200;
            }

            if (str_starts_with($name, $token)) {
                $score += 120;
            }

            if (preg_match('/\b' . preg_quote($token, '/') . '/i', $name) === 1) {
                $score += 90;
            }

            if (strpos($name, $token) !== false) {
                $score += 70;
            }

            if (strpos($category, $token) !== false) {
                $score += 45;
            }

            if (strpos($description, $token) !== false) {
                $score += 25;
            }
        }

        if (ai_assistant_message_has($normalized, ['/\bcheap\b/', '/\bunder\b/', '/\bbudget\b/', '/\blow cost\b/'])) {
            $score += (int) max(0, 250 - $item['price']);
        }

        if (ai_assistant_message_has($normalized, ['/\bspicy\b/', '/\bhot\b/']) && preg_match('/spicy|peri|chilli|masala/i', $item['description']) === 1) {
            $score += 80;
        }

        if (ai_assistant_message_has($normalized, ['/\bveg\b/', '/\bvegetarian\b/', '/\bpaneer\b/']) && preg_match('/paneer|veg|vegetable|cheese|corn|pasta|brownie/i', $item['description'] . ' ' . $item['name']) === 1) {
            $score += 75;
        }

        if ($score <= 0) {
            continue;
        }

        $score += min(40, (int) $item['popularity']);
        $ranked[] = ['score' => $score, 'item' => $item];
    }

    usort($ranked, static function (array $left, array $right): int {
        return ($right['score'] <=> $left['score'])
            ?: ($right['item']['popularity'] <=> $left['item']['popularity'])
            ?: strcmp($left['item']['name'], $right['item']['name']);
    });

    return array_map(
        static function (array $entry): array {
            return [
                'name' => $entry['item']['name'],
                'category' => $entry['item']['category'],
                'description' => $entry['item']['description'],
                'price' => format_price((float) $entry['item']['price']),
                'image' => $entry['item']['image'],
            ];
        },
        array_slice($ranked, 0, $limit)
    );
}

function ai_assistant_help_reply(mysqli $conn, ?array $user, string $message): array
{
    $normalized = ai_assistant_normalize($message);
    $userId = $user !== null ? (int) $user['id'] : null;
    $catalog = ai_assistant_fetch_menu_catalog($conn);

    $base = [
        'reply' => 'I can help with menu ideas, order tracking, payment methods, cart totals, and support details.',
        'chips' => ['Recommend something', 'Track my order', 'Show cheap dishes', 'Payment options'],
        'dishes' => [],
    ];

    if ($normalized === '') {
        return $base;
    }

    if (ai_assistant_message_has($normalized, ['/\b(hi|hello|hey)\b/', '/\bhelp\b/', '/\bsupport\b/', '/\bwhat can you do\b/'])) {
        $base['reply'] = 'I can recommend dishes, answer delivery and payment questions, check your latest order, and guide you to support channels.';
        return $base;
    }

    if (ai_assistant_message_has($normalized, ['/\b(track|where|status|latest order|my order)\b/', '/\border\b/'])) {
        if ($userId === null) {
            return [
                'reply' => 'Log in to let me check your latest order status. Without login, I can still help with menu suggestions and general support.',
                'chips' => ['Recommend pizza', 'Support contact', 'Payment options'],
                'dishes' => [],
            ];
        }

        $orders = get_user_order_history($conn, $userId);
        if ($orders === []) {
            return [
                'reply' => 'You do not have any orders yet. Browse the menu and place your first order to start tracking.',
                'chips' => ['Recommend something', 'Show popular dishes'],
                'dishes' => ai_assistant_recommendation_cards($conn, $userId, 3),
            ];
        }

        $latest = $orders[0];
        return [
            'reply' => 'Your latest order #' . (int) $latest['id'] . ' is currently ' . $latest['status'] . '. Delivery zone: ' . $latest['delivery_zone'] . '. Estimated delivery: ' . format_minutes($latest['estimated_delivery_minutes']) . '.',
            'chips' => ['Need recommendations', 'Payment options', 'Support contact'],
            'dishes' => [],
        ];
    }

    if (ai_assistant_message_has($normalized, ['/\bcart\b/', '/\btotal\b/', '/\bcheckout\b/'])) {
        if ($userId === null) {
            return [
                'reply' => 'Log in to review your cart totals. Delivery fee is usually Rs. 49.00 when the cart has items, plus 5% tax.',
                'chips' => ['Payment options', 'Recommend something'],
                'dishes' => [],
            ];
        }

        $summary = cart_summary($conn, $userId);
        return [
            'reply' => 'Your cart has ' . count($summary['items']) . ' line items. Subtotal: ' . format_price((float) $summary['subtotal']) . ', delivery fee: ' . format_price((float) $summary['delivery_fee']) . ', tax: ' . format_price((float) $summary['tax']) . ', grand total: ' . format_price((float) $summary['grand_total']) . '.',
            'chips' => ['Recommend a side', 'Track my order'],
            'dishes' => [],
        ];
    }

    if (ai_assistant_message_has($normalized, ['/\b(payment|pay|upi|cod|cash|wallet|card)\b/'])) {
        return [
            'reply' => 'Available payment methods are ' . implode(', ', payment_method_options()) . '. Cash on Delivery and UPI QR are the fastest options during checkout.',
            'chips' => ['Track my order', 'Delivery hours'],
            'dishes' => [],
        ];
    }

    if (ai_assistant_message_has($normalized, ['/\b(contact|phone|email|support team|call)\b/'])) {
        return [
            'reply' => 'You can reach QuickBite support at manjeetkumarclg555@gmail.com or +91 7070294101. Service hours are daily from 10:00 AM to 11:00 PM.',
            'chips' => ['Delivery hours', 'Recommend something'],
            'dishes' => [],
        ];
    }

    if (ai_assistant_message_has($normalized, ['/\bhours\b/', '/\bopen\b/', '/\bclosing\b/', '/\btime\b/'])) {
        return [
            'reply' => 'QuickBite service hours are daily from 10:00 AM to 11:00 PM.',
            'chips' => ['Support contact', 'Payment options'],
            'dishes' => [],
        ];
    }

    if (ai_assistant_message_has($normalized, ['/\b(recommend|suggest|hungry|craving|best|popular|what should i eat)\b/', '/\bpizza\b/', '/\bpasta\b/', '/\bwrap\b/', '/\bburger\b/', '/\bdessert\b/', '/\bdrink\b/'])) {
        $dishes = $userId !== null && !ai_assistant_message_has($normalized, ['/\b(pizza|pasta|wrap|burger|dessert|drink|sandwich|sides)\b/'])
            ? ai_assistant_recommendation_cards($conn, $userId, 3)
            : ai_assistant_rank_menu($catalog, $normalized, 4);

        if ($dishes === []) {
            $dishes = ai_assistant_recommendation_cards($conn, $userId, 3);
        }

        return [
            'reply' => $userId !== null
                ? 'Here are the strongest matches based on your request and your activity in QuickBite.'
                : 'Here are some strong dish matches based on what you asked for.',
            'chips' => ['Show spicy dishes', 'Show cheap dishes', 'Track my order'],
            'dishes' => $dishes,
        ];
    }

    $dishes = ai_assistant_rank_menu($catalog, $normalized, 4);
    if ($dishes !== []) {
        return [
            'reply' => 'I found these menu items that best match your message.',
            'chips' => ['Recommend something', 'Payment options'],
            'dishes' => $dishes,
        ];
    }

    return [
        'reply' => 'I could not find a strong match for that request. Ask me for recommendations, order status, cart total, payment options, or support contact.',
        'chips' => ['Recommend something', 'Track my order', 'Support contact'],
        'dishes' => [],
    ];
}
