<?php
declare(strict_types=1);

require_once __DIR__ . '/ai_pipeline.php';

function ensure_notifications_table(mysqli $conn): void
{
    static $checked = false;

    if ($checked) {
        return;
    }

    $conn->query(
        'CREATE TABLE IF NOT EXISTS notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            order_id INT NULL,
            type VARCHAR(50) NOT NULL,
            title VARCHAR(140) NOT NULL,
            message VARCHAR(255) NOT NULL,
            severity VARCHAR(20) NOT NULL DEFAULT "info",
            is_read TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            INDEX idx_notifications_user_created (user_id, created_at),
            INDEX idx_notifications_user_read (user_id, is_read)
        )'
    );

    $checked = true;
}

function create_notification(
    mysqli $conn,
    int $userId,
    ?int $orderId,
    string $type,
    string $title,
    string $message,
    string $severity = 'info'
): void {
    ensure_notifications_table($conn);

    $stmt = $conn->prepare(
        'INSERT INTO notifications(user_id, order_id, type, title, message, severity)
         VALUES(?, ?, ?, ?, ?, ?)'
    );
    $stmt->bind_param('iissss', $userId, $orderId, $type, $title, $message, $severity);
    $stmt->execute();
    $stmt->close();
}

function fetch_user_notifications(mysqli $conn, int $userId, int $limit = 8): array
{
    ensure_notifications_table($conn);

    $limit = max(1, min(25, $limit));
    $result = $conn->query(
        'SELECT id, order_id, type, title, message, severity, is_read, created_at
         FROM notifications
         WHERE user_id = ' . $userId . '
         ORDER BY created_at DESC, id DESC
         LIMIT ' . $limit
    );

    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $row['id'] = (int) $row['id'];
        $row['order_id'] = $row['order_id'] !== null ? (int) $row['order_id'] : null;
        $row['is_read'] = (int) $row['is_read'];
        $rows[] = $row;
    }

    return $rows;
}

function unread_notification_count(mysqli $conn, int $userId): int
{
    ensure_notifications_table($conn);

    $result = $conn->query(
        'SELECT COUNT(*) AS unread_count
         FROM notifications
         WHERE user_id = ' . $userId . ' AND is_read = 0'
    );

    return (int) ($result->fetch_assoc()['unread_count'] ?? 0);
}

function mark_notifications_read(mysqli $conn, int $userId): void
{
    ensure_notifications_table($conn);
    $conn->query('UPDATE notifications SET is_read = 1 WHERE user_id = ' . $userId . ' AND is_read = 0');
}

function percentage(float $value, float $max): float
{
    if ($max <= 0.0) {
        return 0.0;
    }

    return max(0.0, min(100.0, ($value / $max) * 100));
}

function delivery_status_weight(string $status): float
{
    $map = [
        'Placed' => 1.0,
        'Paid' => 1.2,
        'Preparing' => 0.9,
        'Out for Delivery' => 0.4,
        'Delivered' => 0.0,
        'Cancelled' => 0.0,
    ];

    return $map[$status] ?? 0.8;
}

function predict_route_eta(array $signals): int
{
    $trafficPenalty = ['Low' => 1.0, 'Medium' => 4.0, 'High' => 8.0];
    $weatherPenalty = ['Clear' => 0.0, 'Cloudy' => 1.0, 'Rain' => 4.0, 'Fog' => 3.0, 'Storm' => 7.0];

    $baseline = max(
        (float) ($signals['estimated_delivery_minutes'] ?? 0),
        ((float) ($signals['distance_km'] ?? 0) * 2.7) + ((float) ($signals['prep_time_minutes'] ?? 0) * 0.85)
    );

    $predicted = $baseline
        + ($trafficPenalty[$signals['traffic_level'] ?? 'Medium'] ?? 4.0)
        + ($weatherPenalty[$signals['weather_condition'] ?? 'Clear'] ?? 0.0)
        + (max(0, (int) ($signals['total_items'] ?? 0) - 2) * 0.8)
        + (max(0, (int) ($signals['zone_load'] ?? 1) - 1) * 1.8)
        + delivery_status_weight((string) ($signals['status'] ?? 'Placed')) * 2.5;

    return (int) max(12, round($predicted));
}

function route_priority_score(array $signals): float
{
    $predicted = (float) predict_route_eta($signals);
    $distance = (float) ($signals['distance_km'] ?? 0.0);
    $zoneLoad = (int) ($signals['zone_load'] ?? 1);
    $status = (string) ($signals['status'] ?? 'Placed');
    $estimated = max(1.0, (float) ($signals['estimated_delivery_minutes'] ?? 1.0));
    $slack = $estimated - $predicted;

    $score = 50.0
        + (delivery_status_weight($status) * 18.0)
        + ($zoneLoad * 4.5)
        + (($predicted - $estimated) * 0.9)
        + (max(0.0, 8.0 - $distance) * 1.5)
        - max(0.0, $slack);

    return round($score, 2);
}

function evaluate_route_model(array $rows): array
{
    if ($rows === []) {
        return [
            'mae' => 0.0,
            'within_five_rate' => 0.0,
            'avg_prediction_gap' => 0.0,
        ];
    }

    $absoluteError = 0.0;
    $withinFive = 0;
    $predictionGap = 0.0;

    foreach ($rows as $row) {
        $predicted = predict_route_eta($row + ['zone_load' => 1, 'status' => 'Delivered']);
        $actual = (int) $row['actual_delivery_minutes'];
        $error = abs($predicted - $actual);
        $absoluteError += $error;
        $predictionGap += ($predicted - $actual);
        if ($error <= 5) {
            $withinFive++;
        }
    }

    $count = count($rows);

    return [
        'mae' => round($absoluteError / $count, 2),
        'within_five_rate' => round(($withinFive / $count) * 100, 2),
        'avg_prediction_gap' => round($predictionGap / $count, 2),
    ];
}

function fetch_dish_recommendations(mysqli $conn, int $userId, int $limit = 4): array
{
    $limit = max(1, min(8, $limit));

    $historyResult = $conn->query(
        'SELECT oi.food_id, f.category, f.price, SUM(oi.quantity) AS qty
         FROM orders o
         INNER JOIN order_items oi ON oi.order_id = o.id
         INNER JOIN food_items f ON f.id = oi.food_id
         WHERE o.user_id = ' . $userId . ' AND o.status IN ("Placed", "Paid", "Preparing", "Out for Delivery", "Delivered")
         GROUP BY oi.food_id, f.category, f.price'
    );

    $orderedItems = [];
    $categoryAffinity = [];
    $totalHistoryQty = 0;
    $avgItemPrice = 0.0;
    $priceSamples = 0;

    while ($row = $historyResult->fetch_assoc()) {
        $foodId = (int) $row['food_id'];
        $qty = (int) $row['qty'];
        $category = (string) $row['category'];
        $orderedItems[$foodId] = $qty;
        $categoryAffinity[$category] = ($categoryAffinity[$category] ?? 0) + $qty;
        $totalHistoryQty += $qty;
        $avgItemPrice += ((float) $row['price'] * $qty);
        $priceSamples += $qty;
    }

    $avgItemPrice = $priceSamples > 0 ? $avgItemPrice / $priceSamples : 250.0;

    $popularResult = $conn->query(
        'SELECT f.id, f.name, f.category, f.description, f.image, f.price,
                COALESCE(SUM(oi.quantity), 0) AS popularity,
                COUNT(DISTINCT o.user_id) AS customer_span
         FROM food_items f
         LEFT JOIN order_items oi ON oi.food_id = f.id
         LEFT JOIN orders o ON o.id = oi.order_id AND o.status = "Delivered"
         GROUP BY f.id, f.name, f.category, f.description, f.image, f.price
         ORDER BY f.id'
    );

    $similarUserScores = [];
    if ($categoryAffinity !== []) {
        $quotedCategories = array_map(
            static fn (string $category): string => "'" . $conn->real_escape_string($category) . "'",
            array_keys($categoryAffinity)
        );

        $similarResult = $conn->query(
            'SELECT oi.food_id, SUM(oi.quantity) AS similar_qty
             FROM orders o
             INNER JOIN order_items oi ON oi.order_id = o.id
             INNER JOIN food_items f ON f.id = oi.food_id
             WHERE o.user_id <> ' . $userId . '
               AND o.status = "Delivered"
               AND f.category IN (' . implode(', ', $quotedCategories) . ')
             GROUP BY oi.food_id'
        );

        while ($row = $similarResult->fetch_assoc()) {
            $similarUserScores[(int) $row['food_id']] = (int) $row['similar_qty'];
        }
    }

    $maxCategoryAffinity = max(1, array_sum($categoryAffinity));
    $maxPopularity = 1;
    $maxSimilar = max(1, max($similarUserScores ?: [1]));
    $candidates = [];

    while ($row = $popularResult->fetch_assoc()) {
        $foodId = (int) $row['id'];
        $popularity = (int) $row['popularity'];
        $maxPopularity = max($maxPopularity, $popularity);
        $candidates[$foodId] = $row + ['popularity' => $popularity];
    }

    $scored = [];
    foreach ($candidates as $foodId => $food) {
        $category = (string) $food['category'];
        $price = (float) $food['price'];
        $orderedQty = $orderedItems[$foodId] ?? 0;
        $categoryScore = (($categoryAffinity[$category] ?? 0) / $maxCategoryAffinity);
        $popularityScore = $maxPopularity > 0 ? ($food['popularity'] / $maxPopularity) : 0.0;
        $similarityScore = ($similarUserScores[$foodId] ?? 0) / $maxSimilar;
        $reorderScore = min(1.0, $orderedQty / max(1, $totalHistoryQty));
        $priceFit = max(0.0, 1.0 - (abs($price - $avgItemPrice) / max(120.0, $avgItemPrice)));

        $score = ($categoryScore * 0.35)
            + ($popularityScore * 0.2)
            + ($similarityScore * 0.2)
            + ($priceFit * 0.15)
            + ($reorderScore * 0.1);

        $reason = $orderedQty > 0
            ? 'Fits your reorder pattern'
            : (($categoryAffinity[$category] ?? 0) > 0 ? 'Matches your favorite category' : 'Popular with similar customers');

        $scored[] = [
            'id' => $foodId,
            'name' => $food['name'],
            'category' => $category,
            'description' => $food['description'],
            'image' => resolve_food_image((string) $food['image'], (string) $food['name'], $category),
            'price' => $price,
            'score' => round($score, 3),
            'reason' => $reason,
            'ordered_before' => $orderedQty > 0,
        ];
    }

    foreach ($scored as &$dish) {
        $dish['dynamic_score'] = $dish['score'] + (random_int(0, 120) / 1000);
    }
    unset($dish);

    usort(
        $scored,
        static function (array $left, array $right): int {
            return ($right['dynamic_score'] <=> $left['dynamic_score'])
                ?: ($right['score'] <=> $left['score']);
        }
    );

    $selectionPool = array_slice($scored, 0, min(count($scored), max($limit + 3, 6)));
    shuffle($selectionPool);

    usort(
        $selectionPool,
        static fn (array $left, array $right): int => $right['dynamic_score'] <=> $left['dynamic_score']
    );

    $selected = array_slice($selectionPool, 0, $limit);
    foreach ($selected as &$dish) {
        unset($dish['dynamic_score']);
    }
    unset($dish);

    return $selected;
}

function recommendation_coverage_metrics(mysqli $conn): array
{
    $result = $conn->query(
        'SELECT id
         FROM users
         WHERE role = "customer"'
    );

    $customerCount = 0;
    $withRecommendations = 0;

    while ($row = $result->fetch_assoc()) {
        $customerCount++;
        $recommendations = fetch_dish_recommendations($conn, (int) $row['id'], 3);
        if ($recommendations !== []) {
            $withRecommendations++;
        }
    }

    return [
        'customer_count' => $customerCount,
        'coverage_rate' => $customerCount > 0 ? round(($withRecommendations / $customerCount) * 100, 2) : 0.0,
    ];
}

function fetch_active_route_plan(mysqli $conn): array
{
    $result = $conn->query(
        'SELECT o.id, o.user_id, o.status, o.delivery_zone, o.distance_km,
                o.estimated_delivery_minutes, o.prep_time_minutes,
                o.traffic_level, o.weather_condition, o.total,
                u.name AS customer_name,
                COALESCE(SUM(oi.quantity), 0) AS total_items
         FROM orders o
         INNER JOIN users u ON u.id = o.user_id
         LEFT JOIN order_items oi ON oi.order_id = o.id
         WHERE o.status IN ("Placed", "Paid", "Preparing", "Out for Delivery")
         GROUP BY o.id, o.user_id, o.status, o.delivery_zone, o.distance_km,
                  o.estimated_delivery_minutes, o.prep_time_minutes,
                  o.traffic_level, o.weather_condition, o.total, u.name
         ORDER BY o.created_at ASC, o.id ASC'
    );

    $rows = [];
    $zoneLoad = [];
    while ($row = $result->fetch_assoc()) {
        $zone = (string) $row['delivery_zone'];
        $zoneLoad[$zone] = ($zoneLoad[$zone] ?? 0) + 1;
        $rows[] = $row;
    }

    foreach ($rows as &$row) {
        $row['zone_load'] = $zoneLoad[$row['delivery_zone']] ?? 1;
        $row['predicted_eta_minutes'] = predict_route_eta($row);
        $row['priority_score'] = route_priority_score($row);
        $row['recommended_action'] = $row['status'] === 'Out for Delivery'
            ? 'Keep rider on current lane'
            : (($row['zone_load'] ?? 1) > 1 ? 'Batch with same-zone orders' : 'Dispatch directly');
        $row['total'] = (float) $row['total'];
        $row['distance_km'] = (float) $row['distance_km'];
        $row['total_items'] = (int) $row['total_items'];
    }
    unset($row);

    usort(
        $rows,
        static fn (array $left, array $right): int => $right['priority_score'] <=> $left['priority_score']
    );

    return $rows;
}

function fetch_zone_performance(mysqli $conn): array
{
    $result = $conn->query(
        'SELECT delivery_zone,
                COUNT(*) AS total_orders,
                AVG(total) AS avg_order_value,
                AVG(estimated_delivery_minutes) AS avg_eta,
                AVG(CASE WHEN actual_delivery_minutes IS NOT NULL THEN actual_delivery_minutes END) AS avg_actual,
                AVG(CASE WHEN actual_delivery_minutes IS NOT NULL
                    THEN actual_delivery_minutes - estimated_delivery_minutes
                    END) AS avg_delay
         FROM orders
         GROUP BY delivery_zone
         ORDER BY total_orders DESC, delivery_zone ASC'
    );

    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $row['total_orders'] = (int) $row['total_orders'];
        $row['avg_order_value'] = round((float) $row['avg_order_value'], 2);
        $row['avg_eta'] = (float) $row['avg_eta'];
        $row['avg_actual'] = (float) ($row['avg_actual'] ?? 0);
        $row['avg_delay'] = round((float) ($row['avg_delay'] ?? 0), 2);
        $rows[] = $row;
    }

    return $rows;
}

function fetch_status_breakdown(mysqli $conn): array
{
    $result = $conn->query(
        'SELECT status, COUNT(*) AS total_orders
         FROM orders
         GROUP BY status
         ORDER BY total_orders DESC, status ASC'
    );

    $rows = [];
    $max = 1;

    while ($row = $result->fetch_assoc()) {
        $count = (int) $row['total_orders'];
        $max = max($max, $count);
        $rows[] = [
            'status' => $row['status'],
            'total_orders' => $count,
        ];
    }

    foreach ($rows as &$row) {
        $row['share'] = percentage((float) $row['total_orders'], (float) $max);
    }
    unset($row);

    return $rows;
}
?>
