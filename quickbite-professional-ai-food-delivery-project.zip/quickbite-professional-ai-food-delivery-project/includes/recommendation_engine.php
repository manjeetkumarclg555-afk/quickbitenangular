<?php
declare(strict_types=1);

function fetch_recommended_dishes(mysqli $conn, ?int $userId, int $limit = 4): array
{
    $foods = [];
    $result = $conn->query(
        'SELECT f.id, f.name, f.category, f.description, f.image, f.price,
                COUNT(oi.id) AS order_lines,
                COALESCE(SUM(oi.quantity), 0) AS total_qty
         FROM food_items f
         LEFT JOIN order_items oi ON oi.food_id = f.id
         GROUP BY f.id, f.name, f.category, f.description, f.image, f.price
         ORDER BY f.id'
    );

    while ($row = $result->fetch_assoc()) {
        $row['id'] = (int) $row['id'];
        $row['price'] = (float) $row['price'];
        $row['order_lines'] = (int) $row['order_lines'];
        $row['total_qty'] = (int) $row['total_qty'];
        $foods[$row['id']] = $row;
    }

    if ($userId === null) {
        uasort($foods, static function (array $left, array $right): int {
            return ($right['total_qty'] <=> $left['total_qty']) ?: ($left['id'] <=> $right['id']);
        });

        return array_slice(array_values($foods), 0, $limit);
    }

    $stmt = $conn->prepare(
        'SELECT oi.food_id, f.category, SUM(oi.quantity) AS qty
         FROM orders o
         INNER JOIN order_items oi ON oi.order_id = o.id
         INNER JOIN food_items f ON f.id = oi.food_id
         WHERE o.user_id = ?
         GROUP BY oi.food_id, f.category'
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $itemAffinity = [];
    $categoryAffinity = [];

    while ($row = $result->fetch_assoc()) {
        $foodId = (int) $row['food_id'];
        $qty = (int) $row['qty'];
        $category = $row['category'];
        $itemAffinity[$foodId] = ($itemAffinity[$foodId] ?? 0) + $qty;
        $categoryAffinity[$category] = ($categoryAffinity[$category] ?? 0) + $qty;
    }

    $stmt->close();

    foreach ($foods as &$food) {
        $food['score'] =
            ($itemAffinity[$food['id']] ?? 0) * 5 +
            ($categoryAffinity[$food['category']] ?? 0) * 3 +
            $food['total_qty'];
    }
    unset($food);

    uasort($foods, static function (array $left, array $right): int {
        return ($right['score'] <=> $left['score'])
            ?: ($right['total_qty'] <=> $left['total_qty'])
            ?: ($left['id'] <=> $right['id']);
    });

    return array_slice(array_values($foods), 0, $limit);
}

function recommendation_insights(mysqli $conn, int $userId): array
{
    $recommended = fetch_recommended_dishes($conn, $userId, 3);

    if (empty($recommended)) {
        return ['headline' => 'No recommendations yet.', 'reason' => 'Place a delivered order to generate dish affinity signals.'];
    }

    $topCategory = $recommended[0]['category'];

    return [
        'headline' => 'Recommended for your next order',
        'reason' => 'Based on your repeat category preference for ' . $topCategory . ' plus platform-wide demand trends.',
    ];
}

function recommendation_model_metrics(mysqli $conn): array
{
    $query =
        'SELECT o.user_id, o.id AS order_id, o.created_at, oi.food_id
         FROM orders o
         INNER JOIN order_items oi ON oi.order_id = o.id
         WHERE o.status = "Delivered"
         ORDER BY o.user_id ASC, o.created_at ASC, o.id ASC';

    $result = $conn->query($query);
    $history = [];

    while ($row = $result->fetch_assoc()) {
        $userId = (int) $row['user_id'];
        $orderId = (int) $row['order_id'];
        if (!isset($history[$userId][$orderId])) {
            $history[$userId][$orderId] = [];
        }
        $history[$userId][$orderId][] = (int) $row['food_id'];
    }

    $usersEvaluated = 0;
    $hits = 0;

    foreach ($history as $userId => $orders) {
        if (count($orders) < 2) {
            continue;
        }

        $usersEvaluated++;
        $orderIds = array_keys($orders);
        $holdoutOrderId = (int) end($orderIds);
        $holdoutFoods = $orders[$holdoutOrderId];
        $recommended = array_column(fetch_recommended_dishes($conn, (int) $userId, 3), 'id');

        if (count(array_intersect($holdoutFoods, $recommended)) > 0) {
            $hits++;
        }
    }

    return [
        'users_evaluated' => $usersEvaluated,
        'top_3_hit_rate' => $usersEvaluated > 0 ? round(($hits / $usersEvaluated) * 100, 2) : 0.0,
    ];
}
?>
