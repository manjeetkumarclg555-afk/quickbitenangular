<?php
declare(strict_types=1);

require_once __DIR__ . '/ai_pipeline.php';
require_once __DIR__ . '/recommendation_engine.php';
require_once __DIR__ . '/route_optimizer.php';

function analytics_overview(mysqli $conn): array
{
    $metrics = $conn->query(
        'SELECT COUNT(*) AS total_orders,
                SUM(CASE WHEN status = "Delivered" THEN 1 ELSE 0 END) AS delivered_orders,
                SUM(CASE WHEN status IN ("Placed", "Preparing", "Out for Delivery") THEN 1 ELSE 0 END) AS active_orders,
                AVG(CASE WHEN actual_delivery_minutes IS NOT NULL THEN actual_delivery_minutes END) AS avg_actual_delivery,
                AVG(CASE WHEN actual_delivery_minutes IS NOT NULL THEN actual_delivery_minutes - estimated_delivery_minutes END) AS avg_delay
         FROM orders'
    )->fetch_assoc();

    $summary = ai_dataset_summary(fetch_ai_training_dataset($conn));

    return [
        'total_orders' => (int) ($metrics['total_orders'] ?? 0),
        'delivered_orders' => (int) ($metrics['delivered_orders'] ?? 0),
        'active_orders' => (int) ($metrics['active_orders'] ?? 0),
        'avg_actual_delivery' => round((float) ($metrics['avg_actual_delivery'] ?? 0), 1),
        'avg_delay' => round((float) ($metrics['avg_delay'] ?? 0), 1),
        'on_time_rate' => (float) $summary['on_time_rate'],
    ];
}

function zone_analytics(mysqli $conn): array
{
    $result = $conn->query(
        'SELECT delivery_zone,
                COUNT(*) AS total_orders,
                AVG(estimated_delivery_minutes) AS avg_eta,
                AVG(CASE WHEN actual_delivery_minutes IS NOT NULL THEN actual_delivery_minutes END) AS avg_actual,
                AVG(CASE WHEN actual_delivery_minutes IS NOT NULL THEN actual_delivery_minutes - estimated_delivery_minutes END) AS avg_delay,
                AVG(CASE WHEN actual_delivery_minutes IS NOT NULL AND actual_delivery_minutes <= estimated_delivery_minutes THEN 100 ELSE 0 END) AS on_time_rate
         FROM orders
         GROUP BY delivery_zone
         ORDER BY total_orders DESC, delivery_zone ASC'
    );

    $zones = [];
    while ($row = $result->fetch_assoc()) {
        $zones[] = [
            'delivery_zone' => $row['delivery_zone'],
            'total_orders' => (int) $row['total_orders'],
            'avg_eta' => round((float) ($row['avg_eta'] ?? 0), 1),
            'avg_actual' => round((float) ($row['avg_actual'] ?? 0), 1),
            'avg_delay' => round((float) ($row['avg_delay'] ?? 0), 1),
            'on_time_rate' => round((float) ($row['on_time_rate'] ?? 0), 1),
        ];
    }

    return $zones;
}

function category_analytics(mysqli $conn): array
{
    $result = $conn->query(
        'SELECT f.category,
                COUNT(DISTINCT oi.order_id) AS orders_count,
                COALESCE(SUM(oi.quantity), 0) AS total_qty,
                AVG(f.price) AS avg_price
         FROM food_items f
         LEFT JOIN order_items oi ON oi.food_id = f.id
         GROUP BY f.category
         ORDER BY total_qty DESC, f.category ASC'
    );

    $categories = [];
    while ($row = $result->fetch_assoc()) {
        $categories[] = [
            'category' => $row['category'],
            'orders_count' => (int) ($row['orders_count'] ?? 0),
            'total_qty' => (int) ($row['total_qty'] ?? 0),
            'avg_price' => round((float) ($row['avg_price'] ?? 0), 2),
        ];
    }

    return $categories;
}

function eta_model_metrics(mysqli $conn): array
{
    $dataset = fetch_ai_training_dataset($conn);
    $count = count($dataset);

    if ($count < 4) {
        return [
            'evaluation_rows' => $count,
            'mae_minutes' => 0.0,
            'within_10_minutes_rate' => 0.0,
        ];
    }

    $split = max(1, (int) floor($count * 0.7));
    $train = array_slice($dataset, 0, $split);
    $test = array_slice($dataset, $split);
    $bucketDelay = [];
    $bucketCount = [];
    $globalDelay = 0.0;

    foreach ($train as $row) {
        $bucket = $row['delivery_zone'] . '|' . $row['traffic_level'];
        $bucketDelay[$bucket] = ($bucketDelay[$bucket] ?? 0.0) + (float) $row['delivery_delay_minutes'];
        $bucketCount[$bucket] = ($bucketCount[$bucket] ?? 0) + 1;
        $globalDelay += (float) $row['delivery_delay_minutes'];
    }

    $globalDelay = $split > 0 ? $globalDelay / $split : 0.0;
    $totalAbsoluteError = 0.0;
    $withinThreshold = 0;

    foreach ($test as $row) {
        $bucket = $row['delivery_zone'] . '|' . $row['traffic_level'];
        $avgDelay = isset($bucketCount[$bucket]) ? ($bucketDelay[$bucket] / $bucketCount[$bucket]) : $globalDelay;
        $predictedMinutes = (float) $row['estimated_delivery_minutes'] + $avgDelay;
        $error = abs($predictedMinutes - (float) $row['actual_delivery_minutes']);
        $totalAbsoluteError += $error;

        if ($error <= 10) {
            $withinThreshold++;
        }
    }

    $testCount = max(1, count($test));

    return [
        'evaluation_rows' => count($test),
        'mae_minutes' => round($totalAbsoluteError / $testCount, 2),
        'within_10_minutes_rate' => round(($withinThreshold / $testCount) * 100, 2),
    ];
}
?>
