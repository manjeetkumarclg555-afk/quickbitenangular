<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$dbHost = getenv('DB_HOST') ?: 'localhost';
$dbUser = getenv('DB_USER') ?: 'root';
$dbPass = getenv('DB_PASS') ?: '';
$dbName = getenv('DB_NAME') ?: 'food_delivery';

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}

$conn->set_charset('utf8mb4');

function app_name(): string
{
    return 'QuickBite';
}

function path_prefix(): string
{
    $scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    return strpos($scriptName, '/admin/') !== false ? '../' : '';
}

function app_path(string $path): string
{
    return path_prefix() . ltrim($path, '/');
}

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function is_logged_in(): bool
{
    return isset($_SESSION['user']);
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function redirect(string $path): void
{
    header('Location: ' . app_path($path));
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message,
    ];
}

function get_flash(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }

    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);

    return $flash;
}

function require_login(): void
{
    if (!is_logged_in()) {
        flash('error', 'Please log in to continue.');
        redirect('login.php');
    }
}

function require_admin(): void
{
    require_login();

    if ((current_user()['role'] ?? 'customer') !== 'admin') {
        flash('error', 'You do not have access to that page.');
        redirect('index.php');
    }
}

function cart_count(mysqli $conn, int $userId): int
{
    $stmt = $conn->prepare('SELECT COALESCE(SUM(quantity), 0) AS item_count FROM cart WHERE user_id = ?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $count = (int) ($result->fetch_assoc()['item_count'] ?? 0);
    $stmt->close();

    return $count;
}

function cart_summary(mysqli $conn, int $userId): array
{
    $stmt = $conn->prepare(
        'SELECT c.food_id, c.quantity, f.name, f.price, f.category
         FROM cart c
         INNER JOIN food_items f ON f.id = c.food_id
         WHERE c.user_id = ?
         ORDER BY f.name'
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    $items = [];
    $subtotal = 0.0;

    while ($row = $result->fetch_assoc()) {
        $row['quantity'] = (int) $row['quantity'];
        $row['price'] = (float) $row['price'];
        $row['line_total'] = $row['quantity'] * $row['price'];
        $subtotal += $row['line_total'];
        $items[] = $row;
    }

    $stmt->close();

    $deliveryFee = empty($items) ? 0.0 : 49.0;
    $tax = $subtotal * 0.05;

    return [
        'items' => $items,
        'subtotal' => $subtotal,
        'delivery_fee' => $deliveryFee,
        'tax' => $tax,
        'grand_total' => $subtotal + $deliveryFee + $tax,
    ];
}

function format_price(float $amount): string
{
    return 'Rs. ' . number_format($amount, 2);
}

function format_minutes(?int $minutes): string
{
    return $minutes === null ? 'Pending' : $minutes . ' min';
}

function format_datetime(?string $value): string
{
    if ($value === null || $value === '') {
        return 'Not available';
    }

    $timestamp = strtotime($value);
    return $timestamp ? date('d M Y, h:i A', $timestamp) : $value;
}

function resolve_food_image(string $imageValue, string $foodName = '', string $category = ''): string
{
    $imageValue = trim($imageValue);
    if ($imageValue === '') {
        return app_path('images/online_delivery_logo.jpeg');
    }

    $normalized = str_replace('\\', '/', $imageValue);
    if (preg_match('/\.(jpg|jpeg|png|webp|gif)$/i', $normalized)) {
        return preg_match('#^(https?:)?/#i', $normalized) ? $normalized : app_path(ltrim($normalized, '/'));
    }

    $lookup = [];
    $push = static function (string $value) use (&$lookup): void {
        $value = trim($value);
        if ($value !== '') {
            $lookup[] = $value;
        }
    };

    $slugify = static function (string $value): string {
        $value = strtolower($value);
        $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
        return trim($value, '-');
    };

    $push($imageValue);
    $push($foodName);
    $push($category);

    $tokenMap = [
        'PIZZA' => ['pizza.jpg', 'PIZZA-MARGHERITA.jpg', 'Farmhouse_Pizza.jpg'],
        'BURGER' => ['Smokey-Burger.jpg', 'chicken_burger.jpg', 'burger.jpg'],
        'PASTA' => ['white-sauce-pasta.jpg', 'arrabiata-pasta-2.jpg'],
        'SANDWICH' => ['Club-sandwich.jpg'],
        'WRAP' => ['Paneer_Wrap.jpg'],
        'SIDES' => ['Peri-Peri-Fries.jpg'],
        'DRINK' => ['chocolate-shake.jpg', 'lemonicetea.jpg', 'drinks-for-summers.jpg'],
        'DESSERT' => ['Brownie-Sundae-Cups.jpg'],
    ];

    foreach ($tokenMap[strtoupper($imageValue)] ?? [] as $candidate) {
        $push($candidate);
    }

    $push($slugify($foodName) . '.jpg');
    $push($slugify($foodName) . '.jpeg');
    $push(str_replace('-', '_', $slugify($foodName)) . '.jpg');
    $push(str_replace('-', '_', $slugify($foodName)) . '.jpeg');

    $imagesDir = dirname(__DIR__) . '/images/';
    foreach ($lookup as $candidate) {
        $candidate = ltrim($candidate, '/');
        if (is_file($imagesDir . $candidate)) {
            return app_path('images/' . $candidate);
        }
    }

    return app_path('images/online_delivery_logo.jpeg');
}

function payment_method_options(): array
{
    return ['Cash on Delivery', 'UPI QR', 'Card on Delivery', 'Wallet'];
}


function zone_profiles(): array
{
    return [
        'Central' => ['distance_km' => 3.4, 'eta' => 24],
        'North' => ['distance_km' => 6.1, 'eta' => 32],
        'South' => ['distance_km' => 5.8, 'eta' => 29],
        'East' => ['distance_km' => 4.9, 'eta' => 27],
        'West' => ['distance_km' => 7.4, 'eta' => 37],
    ];
}

function delivery_zone_options(): array
{
    return array_keys(zone_profiles());
}

function traffic_level_for_hour(int $hour): string
{
    if (in_array($hour, [12, 13, 19, 20, 21], true)) {
        return 'High';
    }

    if (in_array($hour, [11, 14, 18, 22], true)) {
        return 'Medium';
    }

    return 'Low';
}

function seasonal_weather(): string
{
    $month = (int) date('n');

    if (in_array($month, [6, 7, 8, 9], true)) {
        return 'Rain';
    }

    if (in_array($month, [12, 1], true)) {
        return 'Fog';
    }

    return 'Clear';
}

function estimate_delivery_profile(string $zone, int $itemCount): array
{
    $profiles = zone_profiles();
    $profile = $profiles[$zone] ?? $profiles['Central'];
    $hour = (int) date('G');
    $traffic = traffic_level_for_hour($hour);
    $trafficAdjustment = ['Low' => 0, 'Medium' => 4, 'High' => 8][$traffic];
    $prepTime = 12 + max(0, $itemCount - 1) * 4;
    $estimated = (int) round($profile['eta'] + $trafficAdjustment + max(0, $itemCount - 2) * 1.5);

    return [
        'distance_km' => (float) $profile['distance_km'],
        'estimated_delivery_minutes' => $estimated,
        'prep_time_minutes' => $prepTime,
        'traffic_level' => $traffic,
        'weather_condition' => seasonal_weather(),
    ];
}

function status_options(): array
{
    return ['Placed', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled'];
}

function status_badge_class(string $status): string
{
    $key = strtolower(str_replace([' ', '/'], ['-', '-'], $status));
    return 'status-pill status-' . $key;
}

function get_user_order_history(mysqli $conn, int $userId): array
{
    $stmt = $conn->prepare(
        'SELECT o.id, o.total, o.status, o.delivery_zone, o.payment_method, o.created_at,
                o.estimated_delivery_minutes, o.actual_delivery_minutes, o.customer_rating,
                o.traffic_level, o.weather_condition,
                COALESCE(SUM(oi.quantity), 0) AS total_items,
                COUNT(DISTINCT oi.food_id) AS unique_items,
                GROUP_CONCAT(
                    CONCAT(f.name, " x", oi.quantity)
                    ORDER BY oi.id
                    SEPARATOR ", "
                ) AS item_names
         FROM orders o
         LEFT JOIN order_items oi ON oi.order_id = o.id
         LEFT JOIN food_items f ON f.id = oi.food_id
         WHERE o.user_id = ?
         GROUP BY o.id, o.total, o.status, o.delivery_zone, o.payment_method, o.created_at,
                   o.estimated_delivery_minutes, o.actual_delivery_minutes, o.customer_rating,
                   o.traffic_level, o.weather_condition
         ORDER BY o.created_at DESC, o.id DESC'
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    $orders = [];
    while ($row = $result->fetch_assoc()) {
        $row['total'] = (float) $row['total'];
        $row['total_items'] = (int) $row['total_items'];
        $row['unique_items'] = (int) $row['unique_items'];
        $row['estimated_delivery_minutes'] = $row['estimated_delivery_minutes'] !== null ? (int) $row['estimated_delivery_minutes'] : null;
        $row['actual_delivery_minutes'] = $row['actual_delivery_minutes'] !== null ? (int) $row['actual_delivery_minutes'] : null;
        $row['customer_rating'] = $row['customer_rating'] !== null ? (float) $row['customer_rating'] : null;
        $row['item_names'] = $row['item_names'] !== null ? (string) $row['item_names'] : '';
        $orders[] = $row;
    }

    $stmt->close();

    return $orders;
}
?>
