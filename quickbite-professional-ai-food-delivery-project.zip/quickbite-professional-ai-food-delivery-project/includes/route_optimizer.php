<?php
declare(strict_types=1);

function optimized_delivery_queue(mysqli $conn): array
{
    $result = $conn->query(
        'SELECT o.id, o.status, o.delivery_zone, o.distance_km, o.estimated_delivery_minutes,
                o.traffic_level, o.created_at, u.name AS customer_name
         FROM orders o
         INNER JOIN users u ON u.id = o.user_id
         WHERE o.status IN ("Placed", "Preparing", "Out for Delivery")
         ORDER BY o.created_at ASC, o.id ASC'
    );

    $orders = [];
    $statusWeight = ['Out for Delivery' => 30, 'Preparing' => 20, 'Placed' => 10];
    $trafficWeight = ['Low' => 5, 'Medium' => 10, 'High' => 15];

    while ($row = $result->fetch_assoc()) {
        $score = ($statusWeight[$row['status']] ?? 0)
            + ($trafficWeight[$row['traffic_level']] ?? 0)
            + (float) $row['distance_km']
            + ((int) $row['estimated_delivery_minutes'] / 10);

        $row['id'] = (int) $row['id'];
        $row['distance_km'] = (float) $row['distance_km'];
        $row['estimated_delivery_minutes'] = (int) $row['estimated_delivery_minutes'];
        $row['route_score'] = round($score, 2);
        $row['dispatch_note'] = $row['status'] === 'Out for Delivery'
            ? 'Keep this drop near the front of the run.'
            : 'Batch with other ' . $row['delivery_zone'] . ' orders before dispatch.';
        $orders[] = $row;
    }

    usort($orders, static function (array $left, array $right): int {
        return ($right['route_score'] <=> $left['route_score']) ?: ($left['id'] <=> $right['id']);
    });

    return $orders;
}
?>
