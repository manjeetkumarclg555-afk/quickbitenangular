<?php
declare(strict_types=1);

function payment_method_code(string $method): int
{
    $map = [
        'Cash on Delivery' => 1,
        'UPI' => 2,
        'Card on Delivery' => 3,
        'Wallet' => 4,
    ];

    return $map[$method] ?? 0;
}

function delivery_zone_code(string $zone): int
{
    $map = [
        'Central' => 1,
        'North' => 2,
        'South' => 3,
        'East' => 4,
        'West' => 5,
    ];

    return $map[$zone] ?? 0;
}

function traffic_score(string $level): int
{
    $map = ['Low' => 1, 'Medium' => 2, 'High' => 3];
    return $map[$level] ?? 0;
}

function weather_score(string $condition): int
{
    $map = ['Clear' => 1, 'Cloudy' => 2, 'Rain' => 3, 'Fog' => 4, 'Storm' => 5];
    return $map[$condition] ?? 0;
}

function ai_feature_columns(): array
{
    return [
        'order_id',
        'customer_id',
        'order_hour',
        'order_day_of_week',
        'is_weekend',
        'days_since_customer_signup',
        'customer_lifetime_orders_before',
        'customer_avg_ticket_before',
        'days_since_last_order',
        'total_items',
        'unique_items',
        'subtotal',
        'delivery_fee',
        'tax_amount',
        'basket_total',
        'avg_item_value',
        'payment_method',
        'payment_method_code',
        'delivery_zone',
        'delivery_zone_code',
        'distance_km',
        'prep_time_minutes',
        'estimated_delivery_minutes',
        'actual_delivery_minutes',
        'delivery_delay_minutes',
        'on_time_flag',
        'traffic_level',
        'traffic_score',
        'weather_condition',
        'weather_score',
        'customer_rating',
        'status',
    ];
}

function fetch_ai_training_dataset(mysqli $conn): array
{
    $query =
        'SELECT o.id, o.user_id, u.created_at AS customer_created_at,
                o.subtotal, o.delivery_fee, o.tax_amount, o.total,
                o.payment_method, o.delivery_zone, o.distance_km,
                o.prep_time_minutes, o.estimated_delivery_minutes, o.actual_delivery_minutes,
                o.traffic_level, o.weather_condition, o.customer_rating, o.status, o.created_at,
                agg.total_items, agg.unique_items
         FROM orders o
         INNER JOIN users u ON u.id = o.user_id
         INNER JOIN (
             SELECT order_id, SUM(quantity) AS total_items, COUNT(DISTINCT food_id) AS unique_items
             FROM order_items
             GROUP BY order_id
         ) agg ON agg.order_id = o.id
         WHERE o.status = "Delivered" AND o.actual_delivery_minutes IS NOT NULL
         ORDER BY o.created_at ASC, o.id ASC';

    $result = $conn->query($query);
    $rows = [];
    $customerHistory = [];

    while ($row = $result->fetch_assoc()) {
        $userId = (int) $row['user_id'];
        $createdAtTs = strtotime($row['created_at']);
        $customerCreatedTs = strtotime($row['customer_created_at']);
        $history = $customerHistory[$userId] ?? ['orders' => 0, 'spend' => 0.0, 'last_ts' => null];

        $delay = (int) $row['actual_delivery_minutes'] - (int) $row['estimated_delivery_minutes'];
        $daysSinceLastOrder = $history['last_ts'] === null ? -1 : round(($createdAtTs - $history['last_ts']) / 86400, 1);
        $avgTicketBefore = $history['orders'] > 0 ? round($history['spend'] / $history['orders'], 2) : 0.0;
        $totalItems = (int) $row['total_items'];
        $subtotal = (float) $row['subtotal'];

        $rows[] = [
            'order_id' => (int) $row['id'],
            'customer_id' => $userId,
            'order_hour' => (int) date('G', $createdAtTs),
            'order_day_of_week' => (int) date('N', $createdAtTs),
            'is_weekend' => in_array((int) date('N', $createdAtTs), [6, 7], true) ? 1 : 0,
            'days_since_customer_signup' => max(0, (int) floor(($createdAtTs - $customerCreatedTs) / 86400)),
            'customer_lifetime_orders_before' => $history['orders'],
            'customer_avg_ticket_before' => $avgTicketBefore,
            'days_since_last_order' => $daysSinceLastOrder,
            'total_items' => $totalItems,
            'unique_items' => (int) $row['unique_items'],
            'subtotal' => $subtotal,
            'delivery_fee' => (float) $row['delivery_fee'],
            'tax_amount' => (float) $row['tax_amount'],
            'basket_total' => (float) $row['total'],
            'avg_item_value' => $totalItems > 0 ? round($subtotal / $totalItems, 2) : 0.0,
            'payment_method' => $row['payment_method'],
            'payment_method_code' => payment_method_code($row['payment_method']),
            'delivery_zone' => $row['delivery_zone'],
            'delivery_zone_code' => delivery_zone_code($row['delivery_zone']),
            'distance_km' => (float) $row['distance_km'],
            'prep_time_minutes' => (int) $row['prep_time_minutes'],
            'estimated_delivery_minutes' => (int) $row['estimated_delivery_minutes'],
            'actual_delivery_minutes' => (int) $row['actual_delivery_minutes'],
            'delivery_delay_minutes' => $delay,
            'on_time_flag' => $delay <= 0 ? 1 : 0,
            'traffic_level' => $row['traffic_level'],
            'traffic_score' => traffic_score($row['traffic_level']),
            'weather_condition' => $row['weather_condition'],
            'weather_score' => weather_score($row['weather_condition']),
            'customer_rating' => $row['customer_rating'] !== null ? (float) $row['customer_rating'] : 0.0,
            'status' => $row['status'],
        ];

        $customerHistory[$userId] = [
            'orders' => $history['orders'] + 1,
            'spend' => $history['spend'] + (float) $row['total'],
            'last_ts' => $createdAtTs,
        ];
    }

    return $rows;
}

function ai_dataset_summary(array $rows): array
{
    $count = count($rows);

    if ($count === 0) {
        return [
            'rows' => 0,
            'avg_delay' => 0.0,
            'on_time_rate' => 0.0,
            'avg_distance' => 0.0,
            'avg_basket_total' => 0.0,
        ];
    }

    $delayTotal = 0.0;
    $onTimeTotal = 0;
    $distanceTotal = 0.0;
    $basketTotal = 0.0;

    foreach ($rows as $row) {
        $delayTotal += (float) $row['delivery_delay_minutes'];
        $onTimeTotal += (int) $row['on_time_flag'];
        $distanceTotal += (float) $row['distance_km'];
        $basketTotal += (float) $row['basket_total'];
    }

    return [
        'rows' => $count,
        'avg_delay' => round($delayTotal / $count, 2),
        'on_time_rate' => round(($onTimeTotal / $count) * 100, 2),
        'avg_distance' => round($distanceTotal / $count, 2),
        'avg_basket_total' => round($basketTotal / $count, 2),
    ];
}
?>
