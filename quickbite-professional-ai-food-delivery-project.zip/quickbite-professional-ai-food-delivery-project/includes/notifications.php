<?php
declare(strict_types=1);

function create_notification(mysqli $conn, int $userId, ?int $orderId, string $type, string $title, string $message): void
{
    $stmt = $conn->prepare(
        'INSERT INTO notifications (user_id, order_id, type, title, message)
         VALUES (?, ?, ?, ?, ?)'
    );
    $stmt->bind_param('iisss', $userId, $orderId, $type, $title, $message);
    $stmt->execute();
    $stmt->close();
}

function admin_user_ids(mysqli $conn): array
{
    $result = $conn->query('SELECT id FROM users WHERE role = "admin" ORDER BY id');
    $adminIds = [];

    while ($row = $result->fetch_assoc()) {
        $adminIds[] = (int) $row['id'];
    }

    return $adminIds;
}

function create_admin_notification(mysqli $conn, ?int $orderId, string $type, string $title, string $message): void
{
    foreach (admin_user_ids($conn) as $adminId) {
        create_notification($conn, $adminId, $orderId, $type, $title, $message);
    }
}

function create_order_status_notification(mysqli $conn, int $orderId, string $status): void
{
    $stmt = $conn->prepare(
        'SELECT id, user_id, estimated_delivery_minutes, delivery_zone
         FROM orders
         WHERE id = ?
         LIMIT 1'
    );
    $stmt->bind_param('i', $orderId);
    $stmt->execute();
    $order = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$order) {
        return;
    }

    $title = 'Order #' . (int) $order['id'] . ' is now ' . $status;
    $message = $status === 'Delivered'
        ? 'Delivered to ' . $order['delivery_zone'] . '. Thanks for ordering with QuickBite.'
        : 'Current status: ' . $status . '. Estimated delivery: ' . (int) $order['estimated_delivery_minutes'] . ' minutes.';

    create_notification($conn, (int) $order['user_id'], (int) $order['id'], 'order_status', $title, $message);
}

function fetch_user_notifications(mysqli $conn, int $userId, int $limit = 20): array
{
    $limit = max(1, min(100, $limit));
    $stmt = $conn->prepare(
        'SELECT id, order_id, type, title, message, is_read, created_at
         FROM notifications
         WHERE user_id = ?
         ORDER BY created_at DESC, id DESC
         LIMIT ?'
    );
    $stmt->bind_param('ii', $userId, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    $notifications = [];

    while ($row = $result->fetch_assoc()) {
        $row['id'] = (int) $row['id'];
        $row['order_id'] = $row['order_id'] !== null ? (int) $row['order_id'] : null;
        $row['is_read'] = (int) $row['is_read'];
        $notifications[] = $row;
    }

    $stmt->close();

    return $notifications;
}

function unread_notification_count(mysqli $conn, int $userId): int
{
    $stmt = $conn->prepare(
        'SELECT COUNT(*) AS unread_count
         FROM notifications
         WHERE user_id = ? AND is_read = 0'
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $count = (int) ($stmt->get_result()->fetch_assoc()['unread_count'] ?? 0);
    $stmt->close();

    return $count;
}

function mark_notifications_read(mysqli $conn, int $userId): void
{
    $stmt = $conn->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->close();
}
?>
