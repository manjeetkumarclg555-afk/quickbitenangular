# QuickBite Architecture

## Stack

- Frontend: server-rendered PHP views with shared layout in `includes/layout.php`
- Backend: procedural PHP modules over `mysqli`
- Database: MySQL/MariaDB seeded from `database.sql`
- Runtime: XAMPP/WAMP/Laragon or PHP built-in server

## Application layers

### Presentation

- Customer pages live at the project root: `index.php`, `menu.php`, `cart.php`, `order.php`, `history.php`
- Admin pages live in `admin/`: `dashboard.php`, `ai-modeling.php`, `export-preprocessed-data.php`
- Shared chrome and navigation live in `includes/layout.php`
- Shared styling lives in `css/style.css`

### Domain and service helpers

- `includes/bootstrap.php`
  - session bootstrap
  - database connection
  - shared formatting helpers
  - checkout and order-history helpers
- `includes/ai_pipeline.php`
  - feature engineering for historical order and delivery data
  - model-ready dataset generation and summary metrics
- `includes/intelligence.php`
  - notification persistence and retrieval
  - dish recommendation scoring
  - route ETA prediction and dispatch prioritization
  - analytics helpers for zone and status monitoring

### Data layer

- `users`: admins and customers
- `food_items`: menu catalog
- `cart`: current basket state
- `orders`: operational and delivery features
- `order_items`: basket line items per order
- `notifications`: persistent customer-facing order updates

## Request flow

1. A customer browses `menu.php` and gets ranked dishes if logged in.
2. Checkout in `order.php` creates the order, order items, ETA signals, and an order notification.
3. Payment confirmation in `confirm_upi.php` updates the order and emits a payment notification.
4. Admin dispatch in `admin/dashboard.php` updates statuses, computes route guidance, and pushes customer notifications.
5. Customers review delivery history and notifications in `history.php`.
6. Admins export or inspect AI features in `admin/ai-modeling.php`.

## AI and analytics boundaries

- Recommendation logic is online inference inside the app for lightweight personalization.
- Route optimization is a weighted ETA and priority model designed for seeded operational data without external map APIs.
- Preprocessing stays deterministic so the exported CSV matches in-app analytics.
- The app is structured so heavier ML services can later replace `includes/intelligence.php` while keeping page contracts intact.
