<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/ai_pipeline.php';

require_admin();

$rows = fetch_ai_training_dataset($conn);
$columns = ai_feature_columns();
$filename = 'quickbite_ai_training_dataset_' . date('Ymd_His') . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=' . $filename);

$output = fopen('php://output', 'w');
fputcsv($output, $columns);

foreach ($rows as $row) {
    $line = [];
    foreach ($columns as $column) {
        $line[] = $row[$column];
    }
    fputcsv($output, $line);
}

fclose($output);
exit;
?>
