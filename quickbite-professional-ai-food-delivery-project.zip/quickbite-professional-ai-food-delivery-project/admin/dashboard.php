<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/layout.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $orderId = (int) ($_POST['order_id'] ?? 0);
    $status = trim($_POST['status'] ?? 'Placed');

    $detailStmt = $conn->prepare(
        'SELECT user_id, estimated_delivery_minutes, actual_delivery_minutes, traffic_level,
                weather_condition, distance_km, prep_time_minutes
         FROM orders
         WHERE id = ? LIMIT 1'
    );
    $detailStmt->bind_param('i', $orderId);
    $detailStmt->execute();
    $orderDetail = $detailStmt->get_result()->fetch_assoc();
    $detailStmt->close();

    if ($status === 'Delivered') {
        $estimated = (int) ($orderDetail['estimated_delivery_minutes'] ?? 30);
        $traffic = $orderDetail['traffic_level'] ?? 'Medium';
        $existingActual = $orderDetail['actual_delivery_minutes'] !== null ? (int) $orderDetail['actual_delivery_minutes'] : null;
        $trafficAdjustment = ['Low' => -3, 'Medium' => 2, 'High' => 7][$traffic] ?? 2;
        $actualMinutes = $existingActual ?? max(12, $estimated + $trafficAdjustment + (($orderId % 5) - 2));
        $rating = max(3.8, 4.8 - (($orderId % 4) * 0.2));

        $stmt = $conn->prepare(
            'UPDATE orders
             SET status = ?,
                 actual_delivery_minutes = COALESCE(actual_delivery_minutes, ?),
                 customer_rating = COALESCE(customer_rating, ?),
                 delivered_at = COALESCE(delivered_at, NOW())
             WHERE id = ?'
        );
        $stmt->bind_param('sidi', $status, $actualMinutes, $rating, $orderId);
    } else {
        $stmt = $conn->prepare('UPDATE orders SET status = ? WHERE id = ?');
        $stmt->bind_param('si', $status, $orderId);
    }

    $stmt->execute();
    $stmt->close();

    if ($orderDetail) {
        $predictedEta = predict_route_eta([
            'estimated_delivery_minutes' => (int) ($orderDetail['estimated_delivery_minutes'] ?? 0),
            'distance_km' => (float) ($orderDetail['distance_km'] ?? 0.0),
            'prep_time_minutes' => (int) ($orderDetail['prep_time_minutes'] ?? 0),
            'traffic_level' => (string) ($orderDetail['traffic_level'] ?? 'Medium'),
            'weather_condition' => (string) ($orderDetail['weather_condition'] ?? 'Clear'),
            'total_items' => 2,
            'zone_load' => 1,
            'status' => $status,
        ]);

        create_notification(
            $conn,
            (int) $orderDetail['user_id'],
            $orderId,
            'order_status',
            'Order #' . $orderId . ' is now ' . $status,
            'Latest status: ' . $status . '. AI route monitor predicts roughly ' . $predictedEta . ' minutes for completion.',
            $status === 'Cancelled' ? 'warning' : 'info'
        );
    }

    flash('success', 'Order status updated.');
    redirect('admin/dashboard.php');
}

$metrics = $conn->query(
    'SELECT COUNT(*) AS total_orders,
            SUM(CASE WHEN status = "Delivered" THEN 1 ELSE 0 END) AS delivered_orders,
            SUM(CASE WHEN actual_delivery_minutes IS NOT NULL THEN 1 ELSE 0 END) AS ai_ready_orders,
            AVG(total) AS avg_order_value,
            AVG(CASE WHEN actual_delivery_minutes IS NOT NULL THEN actual_delivery_minutes END) AS avg_delivery_minutes
     FROM orders'
)->fetch_assoc();

$orders = $conn->query(
    'SELECT o.id, o.total, o.status, o.payment_method, o.delivery_address, o.created_at,
            o.delivery_zone, o.distance_km, o.estimated_delivery_minutes, o.actual_delivery_minutes,
            o.traffic_level, o.weather_condition, o.customer_rating,
            u.name AS customer_name, u.email,
            COALESCE(SUM(oi.quantity), 0) AS total_items
     FROM orders o
     INNER JOIN users u ON u.id = o.user_id
     LEFT JOIN order_items oi ON oi.order_id = o.id
     GROUP BY o.id, o.total, o.status, o.payment_method, o.delivery_address, o.created_at,
              o.delivery_zone, o.distance_km, o.estimated_delivery_minutes, o.actual_delivery_minutes,
              o.traffic_level, o.weather_condition, o.customer_rating, u.name, u.email
     ORDER BY o.created_at DESC, o.id DESC'
);

$routePlan = fetch_active_route_plan($conn);
$zonePerformance = fetch_zone_performance($conn);
$statusBreakdown = fetch_status_breakdown($conn);

render_header('Admin Dashboard');
?>
<script>
function toggleItems(id) {
  const div = document.getElementById('items-' + id);
  div.style.display = div.style.display === 'none' ? 'block' : 'none';
}
</script>
<section class="page-banner page-banner-split">
    <div>
        <p class="eyebrow">Operations Center</p>
        <h1>Monitor delivery operations, fulfillment speed, and AI-ready order history.</h1>
        <p class="hero-text">The operations dashboard now combines live order management with the delivery signals needed for downstream modeling.</p>
    </div>
    <div class="admin-actions">
        <a class="button secondary" href="<?php echo h(app_path('admin/ai-modeling.php')); ?>">Open AI Modeling Center</a>
        <a class="button primary" href="<?php echo h(app_path('admin/export-preprocessed-data.php')); ?>">Export CSV Dataset</a>
    </div>
</section>

<section class="kpi-grid">
    <article class="kpi-card">
        <span class="kpi-label">Total Orders</span>
        <strong class="kpi-number"><?php echo (int) ($metrics['total_orders'] ?? 0); ?></strong>
    </article>
    <article class="kpi-card">
        <span class="kpi-label">Delivered Orders</span>
        <strong class="kpi-number"><?php echo (int) ($metrics['delivered_orders'] ?? 0); ?></strong>
    </article>
    <article class="kpi-card">
        <span class="kpi-label">AI Ready Rows</span>
        <strong class="kpi-number"><?php echo (int) ($metrics['ai_ready_orders'] ?? 0); ?></strong>
    </article>
    <article class="kpi-card">
        <span class="kpi-label">Average Delivery Time</span>
        <strong class="kpi-number"><?php echo (int) round((float) ($metrics['avg_delivery_minutes'] ?? 0)); ?> min</strong>
    </article>
</section>

<section class="analytics-grid">
    <article class="info-card slim-card">
        <p class="eyebrow">Route Optimization</p>
        <h2>Dispatch queue ranked by delivery risk and zone batching</h2>
        <?php if (empty($routePlan)): ?>
            <p class="muted">No active orders need routing right now.</p>
        <?php else: ?>
            <div class="mini-table">
                <?php foreach (array_slice($routePlan, 0, 5) as $route): ?>
                    <div class="mini-table-row">
                        <div>
                            <strong>#<?php echo (int) $route['id']; ?> · <?php echo h($route['customer_name']); ?></strong>
                            <div class="cell-meta"><?php echo h($route['delivery_zone']); ?> · <?php echo h($route['status']); ?> · <?php echo h(number_format($route['distance_km'], 1)); ?> km</div>
                        </div>
                        <div class="mini-table-metric">
                            <strong><?php echo (int) $route['predicted_eta_minutes']; ?> min</strong>
                            <div class="cell-meta"><?php echo h($route['recommended_action']); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </article>
    <article class="info-card slim-card">
        <p class="eyebrow">Status Mix</p>
        <h2>Live order-state distribution</h2>
        <?php foreach ($statusBreakdown as $item): ?>
            <div class="progress-row">
                <div class="progress-label">
                    <strong><?php echo h($item['status']); ?></strong>
                    <span><?php echo (int) $item['total_orders']; ?> orders</span>
                </div>
                <div class="progress-track">
                    <span class="progress-bar" style="width: <?php echo h(number_format((float) $item['share'], 2, '.', '')); ?>%"></span>
                </div>
            </div>
        <?php endforeach; ?>
    </article>
</section>

<section class="admin-table-shell">
    <h2>Zone Performance</h2>
    <table class="admin-table dataset-table compact-table">
        <thead>
            <tr>
                <th>Zone</th>
                <th>Orders</th>
                <th>Avg Order Value</th>
                <th>Avg ETA</th>
                <th>Avg Actual</th>
                <th>Avg Delay</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($zonePerformance as $zone): ?>
                <tr>
                    <td><strong><?php echo h($zone['delivery_zone']); ?></strong></td>
                    <td><?php echo (int) $zone['total_orders']; ?></td>
                    <td><?php echo h(format_price((float) $zone['avg_order_value'])); ?></td>
                    <td><?php echo (int) round((float) $zone['avg_eta']); ?> min</td>
                    <td><?php echo (int) round((float) $zone['avg_actual']); ?> min</td>
                    <td><?php echo h(number_format((float) $zone['avg_delay'], 1)); ?> min</td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</section>

<section class="admin-table-shell">
    <table class="admin-table dataset-table">
        <thead>
            <tr>
                <th>Order</th>
                <th>Customer</th>
                <th>Delivery Signals</th>
                <th>Payment</th>
                <th>Total</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($order = $orders->fetch_assoc()): ?>
                <tr>
                    <td>
                        <strong>#<?php echo (int) $order['id']; ?></strong>
                        <span class="cell-meta"><?php echo h(format_datetime($order['created_at'])); ?></span>
                        <span class="cell-meta"><?php echo (int) $order['total_items']; ?> items <span class="toggle-items" onclick="toggleItems(<?php echo (int) $order['id']; ?>)">view details</span></span>
                        <div id="items-<?php echo (int) $order['id']; ?>" class="order-items-detail" style="display: none;">
                            <?php
                            $itemQuery = "
                                SELECT oi.quantity, oi.price, f.name, f.image 
                                FROM order_items oi 
                                INNER JOIN food_items f ON f.id = oi.food_id 
                                WHERE oi.order_id = " . (int) $order['id'] . " 
                                ORDER BY oi.id
                            ";
                            $itemsResult = $conn->query($itemQuery);
                            if ($itemsResult && $itemsResult->num_rows > 0):
                            ?>
                            <table class="order-items-table">
                                <tbody>
                                    <?php while ($itemRow = $itemsResult->fetch_assoc()): ?>
                                        <tr>
                                            <td><img src="<?php echo h(resolve_food_image((string) $itemRow['image'], (string) $itemRow['name'])); ?>" alt="<?php echo h($itemRow['name']); ?>" class="item-image" loading="lazy"></td>
                                            <td><?php echo h($itemRow['name']); ?></td>
                                            <td style="text-align: right"><?php echo (int) $itemRow['quantity']; ?>x</td>
                                            <td style="text-align: right"><?php echo h(format_price((float) $itemRow['price'])); ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                            <?php else: ?>
                                <em>No items.</em>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <strong><?php echo h($order['customer_name']); ?></strong>
                        <span class="cell-meta"><?php echo h($order['email']); ?></span>
                        <span class="cell-meta"><?php echo h($order['delivery_address']); ?></span>
                    </td>
                    <td>
                        <strong><?php echo h($order['delivery_zone']); ?></strong>
                        <span class="cell-meta">Distance: <?php echo h(number_format((float) $order['distance_km'], 1)); ?> km</span>
                        <span class="cell-meta">ETA: <?php echo h(format_minutes((int) $order['estimated_delivery_minutes'])); ?></span>
                        <span class="cell-meta">Actual: <?php echo h(format_minutes($order['actual_delivery_minutes'] !== null ? (int) $order['actual_delivery_minutes'] : null)); ?></span>
                        <span class="cell-meta">Traffic: <?php echo h($order['traffic_level']); ?> | Weather: <?php echo h($order['weather_condition']); ?></span>
                    </td>
                    <td>
                        <strong><?php echo h($order['payment_method']); ?></strong>
                        <span class="cell-meta">Rating: <?php echo $order['customer_rating'] !== null ? h(number_format((float) $order['customer_rating'], 1)) . ' / 5' : 'Pending'; ?></span>
                    </td>
                    <td><?php echo h(format_price((float) $order['total'])); ?></td>
                    <td>
                        <span class="<?php echo h(status_badge_class($order['status'])); ?>"><?php echo h($order['status']); ?></span>
                        <form class="admin-status-form form-stack" method="post">
                            <input type="hidden" name="order_id" value="<?php echo (int) $order['id']; ?>">
                            <select name="status">
                                <?php foreach (status_options() as $status): ?>
                                    <option value="<?php echo h($status); ?>" <?php echo $order['status'] === $status ? 'selected' : ''; ?>>
                                        <?php echo h($status); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button class="button secondary" type="submit">Save</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</section>
<?php render_footer(); ?>
