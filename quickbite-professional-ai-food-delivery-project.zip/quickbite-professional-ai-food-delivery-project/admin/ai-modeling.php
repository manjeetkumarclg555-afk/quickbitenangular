<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/ai_pipeline.php';

require_admin();

$dataset = fetch_ai_training_dataset($conn);
$summary = ai_dataset_summary($dataset);
$routeEvaluation = evaluate_route_model($dataset);
$recommendationCoverage = recommendation_coverage_metrics($conn);
$zonePerformance = fetch_zone_performance($conn);
$previewRows = array_slice(array_reverse($dataset), 0, 8);

render_header('AI Modeling Center');
?>
<section class="page-banner page-banner-split">
    <div>
        <p class="eyebrow">AI Modeling Center</p>
        <h1>Preprocess order history and delivery performance for machine learning workflows.</h1>
        <p class="hero-text">This module prepares training features from historical orders, customer repeat behavior, basket composition, delivery zones, traffic, weather, and timing outcomes.</p>
    </div>
    <div class="admin-actions">
        <a class="button primary" href="<?php echo h(app_path('admin/export-preprocessed-data.php')); ?>">Download Preprocessed CSV</a>
        <a class="button secondary" href="<?php echo h(app_path('admin/dashboard.php')); ?>">Back to Operations</a>
    </div>
</section>

<section class="kpi-grid">
    <article class="kpi-card">
        <span class="kpi-label">Training Rows</span>
        <strong class="kpi-number"><?php echo (int) $summary['rows']; ?></strong>
    </article>
    <article class="kpi-card">
        <span class="kpi-label">On-Time Rate</span>
        <strong class="kpi-number"><?php echo h(number_format((float) $summary['on_time_rate'], 2)); ?>%</strong>
    </article>
    <article class="kpi-card">
        <span class="kpi-label">Average Delay</span>
        <strong class="kpi-number"><?php echo h(number_format((float) $summary['avg_delay'], 2)); ?> min</strong>
    </article>
    <article class="kpi-card">
        <span class="kpi-label">Average Basket</span>
        <strong class="kpi-number"><?php echo h(format_price((float) $summary['avg_basket_total'])); ?></strong>
    </article>
</section>

<section class="kpi-grid compact-grid">
    <article class="kpi-card">
        <span class="kpi-label">Route Model MAE</span>
        <strong class="kpi-number"><?php echo h(number_format((float) $routeEvaluation['mae'], 2)); ?> min</strong>
    </article>
    <article class="kpi-card">
        <span class="kpi-label">Within 5 Min</span>
        <strong class="kpi-number"><?php echo h(number_format((float) $routeEvaluation['within_five_rate'], 2)); ?>%</strong>
    </article>
    <article class="kpi-card">
        <span class="kpi-label">Recommendation Coverage</span>
        <strong class="kpi-number"><?php echo h(number_format((float) $recommendationCoverage['coverage_rate'], 2)); ?>%</strong>
    </article>
    <article class="kpi-card">
        <span class="kpi-label">Customers Scored</span>
        <strong class="kpi-number"><?php echo (int) $recommendationCoverage['customer_count']; ?></strong>
    </article>
</section>

<section class="analytics-grid three-up">
    <article class="feature-card">
        <h2>Feature Engineering</h2>
        <p>Transforms operational data into structured model features such as order hour, weekend flag, repeat-order history, average ticket size, zone codes, traffic scores, weather scores, and delay labels.</p>
    </article>
    <article class="feature-card">
        <h2>Suggested Models</h2>
        <p>Use the dataset for ETA regression, on-time classification, dish recommendation ranking, delivery-risk scoring, or route and staffing optimization experiments.</p>
    </article>
    <article class="feature-card">
        <h2>Operational Value</h2>
        <p>Admins can export a consistent training dataset, inspect model accuracy, and compare zone performance without stitching tables together outside the app.</p>
    </article>
</section>

<section class="analytics-grid">
    <article class="info-card slim-card">
        <p class="eyebrow">Recommendation Engine</p>
        <h2>Ranking logic used for personalized dishes</h2>
        <p>The recommendation service combines category affinity, reorder history, similar-customer demand, popularity, and price-fit into one weighted ranking score per dish.</p>
        <p class="muted">This behaves like a lightweight hybrid recommender and can later be replaced with collaborative filtering or learning-to-rank models using the exported dataset.</p>
    </article>
    <article class="info-card slim-card">
        <p class="eyebrow">Route Model</p>
        <h2>Weighted ETA prediction for dispatch decisions</h2>
        <p>The route optimizer predicts completion time from distance, prep time, traffic, weather, active zone load, and order status, then ranks active orders by urgency and batching opportunity.</p>
        <p class="muted">Current seeded-data validation: MAE <?php echo h(number_format((float) $routeEvaluation['mae'], 2)); ?> min, within 5 minutes <?php echo h(number_format((float) $routeEvaluation['within_five_rate'], 2)); ?>%.</p>
    </article>
</section>

<section class="admin-table-shell">
    <h2>Zone Benchmark Snapshot</h2>
    <table class="admin-table dataset-table compact-table">
        <thead>
            <tr>
                <th>Zone</th>
                <th>Orders</th>
                <th>Avg Order Value</th>
                <th>Avg ETA</th>
                <th>Avg Actual</th>
                <th>Avg Delay</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($zonePerformance as $zone): ?>
                <tr>
                    <td><?php echo h($zone['delivery_zone']); ?></td>
                    <td><?php echo (int) $zone['total_orders']; ?></td>
                    <td><?php echo h(format_price((float) $zone['avg_order_value'])); ?></td>
                    <td><?php echo (int) round((float) $zone['avg_eta']); ?> min</td>
                    <td><?php echo (int) round((float) $zone['avg_actual']); ?> min</td>
                    <td><?php echo h(number_format((float) $zone['avg_delay'], 1)); ?> min</td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</section>

<section class="info-card code-card">
    <p class="eyebrow">CLI Export</p>
    <h2>Run the dataset pipeline from terminal</h2>
    <pre>php scripts/preprocess_delivery_ai_dataset.php</pre>
</section>

<section class="admin-table-shell">
    <h2>Dataset Preview</h2>
    <?php if (empty($previewRows)): ?>
        <p class="muted">No delivered historical orders are available yet for preprocessing.</p>
    <?php else: ?>
        <table class="admin-table dataset-table compact-table">
            <thead>
                <tr>
                    <th>Order</th>
                    <th>Hour</th>
                    <th>Repeat Orders Before</th>
                    <th>Zone</th>
                    <th>Distance</th>
                    <th>ETA</th>
                    <th>Actual</th>
                    <th>Delay</th>
                    <th>On Time</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($previewRows as $row): ?>
                    <tr>
                        <td>#<?php echo (int) $row['order_id']; ?></td>
                        <td><?php echo (int) $row['order_hour']; ?></td>
                        <td><?php echo (int) $row['customer_lifetime_orders_before']; ?></td>
                        <td><?php echo h($row['delivery_zone']); ?></td>
                        <td><?php echo h(number_format((float) $row['distance_km'], 1)); ?> km</td>
                        <td><?php echo (int) $row['estimated_delivery_minutes']; ?> min</td>
                        <td><?php echo (int) $row['actual_delivery_minutes']; ?> min</td>
                        <td><?php echo (int) $row['delivery_delay_minutes']; ?> min</td>
                        <td><?php echo (int) $row['on_time_flag'] === 1 ? 'Yes' : 'No'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>
<?php render_footer(); ?>
