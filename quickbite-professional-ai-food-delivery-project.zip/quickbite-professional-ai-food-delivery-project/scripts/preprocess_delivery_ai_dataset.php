<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/ai_pipeline.php';

$rows = fetch_ai_training_dataset($conn);
$columns = ai_feature_columns();
$outputDir = __DIR__ . '/../exports';

if (!is_dir($outputDir)) {
    mkdir($outputDir, 0777, true);
}

$filePath = $outputDir . '/ai_training_dataset.csv';
$output = fopen($filePath, 'w');

fputcsv($output, $columns);
foreach ($rows as $row) {
    $line = [];
    foreach ($columns as $column) {
        $line[] = $row[$column];
    }
    fputcsv($output, $line);
}

fclose($output);

echo 'Wrote ' . count($rows) . ' rows to ' . $filePath . PHP_EOL;
?>
