<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/intelligence.php';

function assert_or_fail(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, '[FAIL] ' . $message . PHP_EOL);
        exit(1);
    }

    echo '[PASS] ' . $message . PHP_EOL;
}

$dataset = fetch_ai_training_dataset($conn);
assert_or_fail(count($dataset) > 0, 'AI preprocessing returns delivered training rows.');

$routeEval = evaluate_route_model($dataset);
assert_or_fail($routeEval['mae'] <= 12.0, 'Route model MAE stays within seeded-data tolerance.');
assert_or_fail($routeEval['within_five_rate'] >= 40.0, 'Route model lands within five minutes for a usable share of seeded orders.');

$recommendationStart = microtime(true);
$recommendations = fetch_dish_recommendations($conn, 2, 4);
$recommendationDuration = microtime(true) - $recommendationStart;
assert_or_fail(count($recommendations) > 0, 'Recommendation engine returns dishes for a seeded customer.');
assert_or_fail($recommendationDuration < 1.0, 'Recommendation query finishes within one second on seeded data.');

$routeStart = microtime(true);
$routePlan = fetch_active_route_plan($conn);
$routeDuration = microtime(true) - $routeStart;
assert_or_fail($routeDuration < 1.0, 'Route optimization query finishes within one second on seeded data.');

if (count($routePlan) > 1) {
    assert_or_fail(
        $routePlan[0]['priority_score'] >= $routePlan[1]['priority_score'],
        'Route plan is sorted by descending priority score.'
    );
}

$userId = 2;
$beforeCount = unread_notification_count($conn, $userId);
$conn->begin_transaction();
create_notification($conn, $userId, 1, 'test_event', 'Validation notification', 'Rollback-only notification.', 'info');
$afterCount = unread_notification_count($conn, $userId);
assert_or_fail($afterCount === $beforeCount + 1, 'Notification subsystem persists unread updates.');
$conn->rollback();

echo PHP_EOL;
echo 'Summary' . PHP_EOL;
echo '- Training rows: ' . count($dataset) . PHP_EOL;
echo '- Route MAE: ' . $routeEval['mae'] . ' min' . PHP_EOL;
echo '- Within five minutes: ' . $routeEval['within_five_rate'] . '%' . PHP_EOL;
echo '- Recommendations returned: ' . count($recommendations) . PHP_EOL;
echo '- Recommendation latency: ' . number_format($recommendationDuration, 4) . ' s' . PHP_EOL;
echo '- Route latency: ' . number_format($routeDuration, 4) . ' s' . PHP_EOL;
